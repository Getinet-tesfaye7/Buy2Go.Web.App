import React, {useRef, useState} from 'react';
import {View, StyleSheet,Text} from 'react-native';
import LottieView from 'lottie-react-native';
import {useEffect} from 'react';

const SplashScreen = props => {
  const [authLoaded, setAuthLoaded] = useState(false);
  const [animationLoaded, setAnimationLoaded] = useState(false);

  const ref = useRef(null);

  useEffect(() => {
    setTimeout(() => {
      setAuthLoaded(true);
    }, 10);
  }, []);

  const onAnimationFinish = () => {
    setAnimationLoaded(true);
  };

  useEffect(() => {
    if (authLoaded && animationLoaded) {
      props.navigation.replace('Home');
    }
  }, [authLoaded, animationLoaded, props.navigation]);

  return (
    <View style={styles.root}>
       <View style={{ alignItems:'center',justifyContent:'center'}}>
     <Text style={styles.red}> buy2go.et </Text>
     <Text style={styles.red}> 9191 </Text>
  
     </View>
      <LottieView
        ref={animation => {
          ref.current = animation;
        }}
        style={styles.lottieView}
        source={require('../../Assets/splash.json')}
        autoPlay
        loop={false}
        onAnimationFinish={onAnimationFinish}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lottieView: {
    width: '100%',
  },
  red:
  {
    fontSize:30,
    fontWeight:'800'
  }
});

export default SplashScreen;